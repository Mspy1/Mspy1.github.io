# Reproducing the vendored demo

The shipped files under `/games/shapez/v/8a79de52/` are the official prebuilt
production demo for upstream commit `8a79de5255fb6756f3a1d26579b1e9bc36e0c811`
(release 1.5.7), with a small, fully documented local patch applied.

This archive is the **complete corresponding source** for the unmodified
upstream program (all of `src/`, `gulp/`, `res/`, `res_raw/`, `translations/`,
build config and `yarn.lock` at that pin), **minus** the two asset classes that
are deliberately not redistributed:

- `res_raw/sounds/` (music + SFX) — omitted; the soundtrack is sold separately
  and no redistribution grant was located.
- `res/fonts/GameFont.woff2` — omitted; no embedded license/copyright metadata
  could be read (Brotli-compressed). The demo maps `GameFont` to a system UI
  font instead.

No source was removed otherwise. The official upstream sources and build rules
are intact; `gulp/` contains the Webpack/Gulp build that produces `bundle.js`,
`main.css` and `async-resources.css` from `src/` and the `res*/` trees.

## What was changed in the shipped prebuilt

`reproduce/patch-bundle.cjs` takes the untouched official `bundle.js` and applies
only these mechanical edits:

1. The single cache-bust literal `"/v/8a79de52/"` becomes
   `"/games/shapez/v/8a79de52/"` so every same-origin asset resolves from the
   nested Pages path.
2. Music (`_load3`) and SFX (`sound_load`) loaders resolve immediately — silence.
3. Google-Analytics shims and all external network entry points
   (`_fetchPlayerCount`, `wrapper_ref2` ad check, `_fetchDiscounts`,
   `browser_game_analytics_initialize`, `_sendToApi`, `_fetchABVariant`,
   `_note`, `_noteMinor`, `_sendGameEvent`, and the game-event handlers) become
   no-ops. No external request is attempted.
4. `game.html` keeps the official markup, adds a restrictive CSP, replaces the
   font `src` with `local()` system fonts, and recomputes the SRI hash of the
   patched bundle.
5. `index.html` is a thin wrapper that adds the site's existing themed return
   bar above a viewport-filling same-origin iframe running `game.html`.

To reproduce the CSS/JS from source instead of using the official prebuilt, run
the upstream build at this pin (`yarn`, then `cd gulp && yarn gulp build.web-shapezio`)
and then apply the same patch script. Upstream build requires Node 16, Yarn,
Java and ffmpeg; see the upstream README.
