/*
 * Reproduce the exact shipped bundle.js from the official prebuilt bundle.js
 * for upstream pin 8a79de5255fb6756f3a1d26579b1e9bc36e0c811.
 *
 * Usage: node patch-bundle.cjs <official-bundle.js> <output-bundle.js>
 * Requires only Node.js; no dependencies.
 */
const fs = require('fs');
const crypto = require('crypto');

const [, , input, output] = process.argv;
if (!input || !output) throw new Error('usage: node patch-bundle.cjs <in> <out>');

function noop(bundle, name, body = '') {
  const marker = 'function ' + name + '(';
  const start = bundle.indexOf(marker);
  if (start < 0) throw new Error('function not found: ' + name);
  const open = bundle.indexOf('{', start);
  let depth = 1, i = open + 1;
  for (; i < bundle.length && depth; i++) {
    if (bundle[i] === '{') depth++;
    else if (bundle[i] === '}') depth--;
  }
  return bundle.slice(0, open + 1) + body + bundle.slice(i - 1);
}

let b = fs.readFileSync(input, 'utf8');

// 1. Nested Pages path mapping.
b = b.replace('"/v/8a79de52/"', '"/games/shapez/v/8a79de52/"');

// 2. Silence: audio loaders never fetch mp3s.
b = noop(b, 'sound_load', 'return Promise.resolve()');
b = noop(b, '_load3', 'return Promise.resolve()');

// 3. Analytics shims no-op.
for (const n of [
  'google_analytics_initialize', 'google_analytics_setUserContext',
  'google_analytics_trackStateEnter', 'google_analytics_trackDecision',
]) b = noop(b, n, 'return Promise.resolve()');
b = b.replaceAll('window.gtag', 'window.__disabledAnalytics');

// 4. Every external network entry point no-op.
b = noop(b, '_fetchPlayerCount');
b = noop(b, 'wrapper_ref2', 'e(!0)'); // report "adblock" => no ad provider
b = noop(b, '_fetchDiscounts');
b = noop(b, '_sendBeacon');
b = noop(b, 'browser_game_analytics_initialize', 'return Promise.resolve()');
b = noop(b, '_sendToApi', 'return Promise.resolve()');
b = noop(b, '_fetchABVariant', 'return Promise.resolve()');
b = noop(b, '_note');
b = noop(b, '_noteMinor');
b = noop(b, '_sendGameEvent');
b = noop(b, 'game_analytics_handleGameStarted');
b = noop(b, 'game_analytics_handleLevelCompleted');
b = noop(b, 'game_analytics_handleUpgradeUnlocke');

fs.writeFileSync(output, b);
console.log('wrote', output, 'bytes', b.length);
console.log('SRI sha256-' + crypto.createHash('sha256').update(b).digest('base64'));
